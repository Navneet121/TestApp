package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.ADFUtils;

import com.infy.semintegration.common.view.utils.JSFUtils;

import java.io.IOException;
import java.io.OutputStream;

import java.math.BigDecimal;

import javax.faces.event.ValueChangeEvent;

import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;

import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

import oracle.jbo.domain.Date;

import java.sql.SQLException;

import java.text.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import javax.faces.event.ActionEvent;

import javax.faces.model.SelectItem;

import oracle.adf.controller.binding.BindingUtils;
import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.context.AdfFacesContext;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.OperationBinding;

import oracle.jbo.NavigatableRowIterator;
import oracle.jbo.RowSetIterator;

import oracle.jbo.ViewCriteria;
import oracle.jbo.server.ViewObjectImpl;

import org.apache.myfaces.trinidad.model.UploadedFile;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import oracle.adf.share.security.SecurityContext;

public class RateCardBackingBean {

    private RichSelectOneChoice bndSupplierSiteId;
    private RichOutputText bndBUName;
    private RichPanelFormLayout bndBuName1;
    private RichInputText bndLineNumber;
    private RichTable bndTable;
    private static int lineNumCounter;

    public RateCardBackingBean() {
        
        
    }

    List<SelectItem> supplierList;
    List<SelectItem> poList;
    String lineNumber;
    String rate;
    String poIdValue;
    String supplierSiteIdVal = "";
    String supplierSiteId = "";


    UploadedFile rateCardFile;

    public void generateRateCardTemplate(FacesContext facesContext, OutputStream outputStream) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("RateCard Data");
        Row row = sheet.createRow(0);

        XSSFCellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        Font font = workbook.createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        cellStyle.setFont(font);

        Cell cell0 = row.createCell(0);
        cell0.setCellValue("Rate Card Number");
        cell0.setCellStyle(cellStyle);

        Cell cell1 = row.createCell(1);
        cell1.setCellValue("Contract Number");
        cell1.setCellStyle(cellStyle);

        Cell cell2 = row.createCell(2);
        cell2.setCellValue("Supplier Name");
        cell2.setCellStyle(cellStyle);

        Cell cell3 = row.createCell(3);
        cell3.setCellValue("Supplier Site");
        cell3.setCellStyle(cellStyle);

        Cell cell4 = row.createCell(4);
        cell4.setCellValue("Effective From Date");
        cell4.setCellStyle(cellStyle);

        Cell cell5 = row.createCell(5);
        cell5.setCellValue("Effective To Date");
        cell5.setCellStyle(cellStyle);

        row = sheet.createRow(3);

        Cell cellr0 = row.createCell(0);
        cellr0.setCellValue("Line Number");
        cellr0.setCellStyle(cellStyle);

        Cell cellr1 = row.createCell(1);
        cellr1.setCellValue("Role Type");
        cellr1.setCellStyle(cellStyle);

        Cell cellr2 = row.createCell(2);
        cellr2.setCellValue("Role");
        cellr2.setCellStyle(cellStyle);

        Cell cellr3 = row.createCell(3);
        cellr3.setCellValue("Region");
        cellr3.setCellStyle(cellStyle);

        Cell cellr4 = row.createCell(4);
        cellr4.setCellValue("Work Type");
        cellr4.setCellStyle(cellStyle);

        Cell cellr5 = row.createCell(5);
        cellr5.setCellValue("Rate Type");
        cellr5.setCellStyle(cellStyle);

        Cell cellr6 = row.createCell(6);
        cellr6.setCellValue("Rate ");
        cellr6.setCellStyle(cellStyle);

        Cell cellr7 = row.createCell(7);
        cellr7.setCellValue("UOM");
        cellr7.setCellStyle(cellStyle);

        Cell cellr8 = row.createCell(8);
        cellr8.setCellValue("Effective Date From");
        cellr8.setCellStyle(cellStyle);

        Cell cellr9 = row.createCell(9);
        cellr9.setCellValue("Effective Date To");
        cellr9.setCellStyle(cellStyle);

        Cell cellr10 = row.createCell(10);
        cellr10.setCellValue("Comments");
        cellr10.setCellStyle(cellStyle);

        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
        sheet.autoSizeColumn(2);
        sheet.autoSizeColumn(3);
        sheet.autoSizeColumn(4);
        sheet.autoSizeColumn(5);
        sheet.autoSizeColumn(6);
        sheet.autoSizeColumn(7);
        sheet.autoSizeColumn(8);
        sheet.autoSizeColumn(9);
        sheet.autoSizeColumn(10);

        try {
            workbook.write(outputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void createRateCardFromFile(DialogEvent dialogEvent) {
        if (rateCardFile != null) {
            try {
                String userRole = (String) JSFUtils.getFromSession("role");
                oracle.jbo.domain.Number partyId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("partyId");

                Workbook workbook = WorkbookFactory.create(rateCardFile.getInputStream());
                Sheet sheet = workbook.getSheetAt(0);
                Row excelHeaderRow = sheet.getRow(1);
                Cell rateCardNumberCell = excelHeaderRow.getCell(0);
                Cell contractNumberCell = excelHeaderRow.getCell(1);
                Cell supplierNameCell = excelHeaderRow.getCell(2);
                Cell supplierSiteNameCell = excelHeaderRow.getCell(3);
                Cell effectiveFromCell = excelHeaderRow.getCell(4);
                Cell effectiveToCell = excelHeaderRow.getCell(5);

                if (rateCardNumberCell == null) {
                    JSFUtils.addFacesErrorMessage("rate Card Number cannot be null");
                    return;
                }
                String rateCardNumber = RateCardBackingBean.getStringCellValue(rateCardNumberCell, workbook);
                if (rateCardNumber == null || rateCardNumber.trim().equals("")) {
                    JSFUtils.addFacesErrorMessage("rate Card Number cannot be null");
                    return;
                }
                String contractNumber = RateCardBackingBean.getStringCellValue(contractNumberCell, workbook);
                String supplierName = RateCardBackingBean.getStringCellValue(supplierNameCell, workbook);
                String supplierSiteName = RateCardBackingBean.getStringCellValue(supplierSiteNameCell, workbook);
                String effectiveFrom = RateCardBackingBean.getDateCellValue(effectiveFromCell);
                String effectiveTo = RateCardBackingBean.getDateCellValue(effectiveToCell);


                oracle.jbo.domain.Number rateCardNumberValue = new oracle.jbo.domain.Number(rateCardNumber);
                Date effectiveFromDate = castToJBODate(effectiveFrom);
                Date effectiveToDate = castToJBODate(effectiveTo);

                oracle.jbo.ViewObject headerObject = ADFUtils.findIterator("RateCardHeaderIterator").getViewObject();
                oracle.jbo.Row headerRow = headerObject.createRow();

                headerRow.setAttribute("RateCardNumber", rateCardNumberValue);
                headerRow.setAttribute("EffectiveDateFrom", effectiveFromDate);
                headerRow.setAttribute("EffectiveDateTo", effectiveToDate);

                oracle.jbo.domain.Number poHeaderId = null;
                if (contractNumber != null && !contractNumber.trim().equals("")) {
                    oracle.jbo.Row[] rows =
                        ADFUtils.findIterator("ContractsLOVIterator").getViewObject().getFilteredRows("OrderNumber",
                                                                                                      contractNumber.trim());
                    if (rows != null && rows.length > 0) {
                        poHeaderId = (oracle.jbo.domain.Number) rows[0].getAttribute("PoHeaderId");
                        if (userRole.equalsIgnoreCase("SUPPLIER")) {
                            if (((oracle.jbo.domain.Number) rows[0].getAttribute("SupplierId")).compareTo(partyId) !=
                                0) {
                                JSFUtils.addFacesErrorMessage("Supplier user cannot enter ratecards for contracts of other suppliers");
                            }
                        }
                    } else {
                        JSFUtils.addFacesErrorMessage("Entered Contract number does not exists");
                        return;
                    }
                }
                headerRow.setAttribute("PoHeaderId", poHeaderId);

                oracle.jbo.domain.Number supplierId = null;
                if (poHeaderId == null) {

                    if (supplierName != null && !supplierName.trim().equals("")) {
                        oracle.jbo.Row[] rows =
                            ADFUtils.findIterator("SupplierLOVIterator").getViewObject().getFilteredRows("SupplierName",
                                                                                                         supplierName.trim());
                        if (rows != null && rows.length > 0) {
                            supplierId = (oracle.jbo.domain.Number) rows[0].getAttribute("SupplierId");
                        } else {
                            JSFUtils.addFacesErrorMessage("Entered Supplier does not exists");
                            return;
                        }
                    }
                    if (supplierId != null) {
                        headerRow.setAttribute("SupplierId", supplierId);
                        if (userRole.equalsIgnoreCase("SUPPLIER")) {
                            if (supplierId.compareTo(partyId) != 0) {
                                JSFUtils.addFacesErrorMessage("Supplier user cannot enter ratecards for another suppliers");
                            }
                        }
                    } else {
                        JSFUtils.addFacesErrorMessage("Please enter a Contract or a Supplier and upload again");
                    }

                    OperationBinding fetchSupplierSites = ADFUtils.findOperation("ExecuteSupplierSites");
                    fetchSupplierSites.getParamsMap().put("bSupplierId", supplierId);
                    fetchSupplierSites.execute();

                    oracle.jbo.domain.Number supplierSiteId = null;
                    if (supplierSiteName != null && !supplierSiteName.trim().equals("")) {
                        oracle.jbo.Row[] rows =
                            ADFUtils.findIterator("SupplierSitesLOVIterator").getViewObject().getFilteredRows("SupplierSiteName",
                                                                                                              supplierSiteName.trim());
                        if (rows != null && rows.length > 0) {
                            supplierSiteId = (oracle.jbo.domain.Number) rows[0].getAttribute("SupplierSiteId");
                        } else {
                            JSFUtils.addFacesErrorMessage("Entered Supplier site does not exists");
                            return;
                        }
                    }

                    if (poHeaderId == null && supplierId != null && supplierSiteId == null) {
                        JSFUtils.addFacesErrorMessage("Supplier site is required");
                        return;
                    }

                    headerRow.setAttribute("SupplierSiteId", supplierSiteId);
                }

                if (poHeaderId != null) {
                    oracle.jbo.Row[] rows =
                        ADFUtils.findIterator("RateCardSearchIterator").getViewObject().getFilteredRows("PoHeaderId",
                                                                                                        poHeaderId);
                    if (rows != null && rows.length > 0) {
                        for (oracle.jbo.Row row : rows) {
                            oracle.jbo.domain.Number curRateCardNumber =
                                (oracle.jbo.domain.Number) row.getAttribute("RateCardNumber");
                            if (rateCardNumberValue.compareTo(curRateCardNumber) != 0) {
                                Date fromDate = (Date) row.getAttribute("EffectiveDateFrom");
                                Date toDate = (Date) row.getAttribute("EffectiveDateTo");

                                if (fromDate.compareTo(effectiveFromDate) < 0 && toDate != null &&
                                    toDate.compareTo(effectiveFromDate) < 0) {
                                } else if (fromDate.compareTo(effectiveFromDate) > 0 && effectiveToDate != null &&
                                           fromDate.compareTo(effectiveToDate) > 0) {
                                } else {
                                    JSFUtils.addFacesErrorMessage("Rate card already defined for the selected contract for the mentioned effective period");
                                    return;
                                }
                            }
                        }
                    }
                } else {
                    oracle.jbo.Row[] rows =
                        ADFUtils.findIterator("RateCardSearchIterator").getViewObject().getFilteredRows("SupplierId",
                                                                                                        supplierId);
                    if (rows != null && rows.length > 0) {
                        for (oracle.jbo.Row row : rows) {
                            oracle.jbo.domain.Number curRateCardNumber =
                                (oracle.jbo.domain.Number) row.getAttribute("RateCardNumber");
                            if (rateCardNumberValue.compareTo(curRateCardNumber) != 0) {
                                oracle.jbo.domain.Number oldPoHeaderId =
                                    (oracle.jbo.domain.Number) row.getAttribute("PoHeaderId");
                                if (oldPoHeaderId == null) {
                                    Date fromDate = (Date) row.getAttribute("EffectiveDateFrom");
                                    Date toDate = (Date) row.getAttribute("EffectiveDateTo");

                                    if (fromDate.compareTo(effectiveFromDate) < 0 && toDate != null &&
                                        toDate.compareTo(effectiveFromDate) < 0) {
                                    } else if (fromDate.compareTo(effectiveFromDate) > 0 && effectiveToDate != null &&
                                               fromDate.compareTo(effectiveToDate) > 0) {
                                    } else {
                                        JSFUtils.addFacesErrorMessage("Rate card already defined for the selected supplier for the mentioned effective period");
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
                headerRow.setAttribute("Status", "DRAFT");

                headerObject.insertRow(headerRow);

                //fetching line rows
                int count = 4;

                oracle.jbo.ViewObject rateCardLinesVO = ADFUtils.findIterator("RateCardLineIterator").getViewObject();
                while (true) {
                    Row excelRateCardLineRow = sheet.getRow(count++);
                    if (excelRateCardLineRow == null) {
                        break;
                    }

                    Cell lineNumberCell = excelRateCardLineRow.getCell(0);
                    if (lineNumberCell == null) {
                        break;
                    }

                    Cell roleTypeCell = excelRateCardLineRow.getCell(1);
                    Cell roleCell = excelRateCardLineRow.getCell(2);
                    Cell regionCell = excelRateCardLineRow.getCell(3);
                    Cell workTypeCell = excelRateCardLineRow.getCell(4);
                    Cell rateTypeCell = excelRateCardLineRow.getCell(5);
                    Cell rateCell = excelRateCardLineRow.getCell(6);
                    Cell uomCell = excelRateCardLineRow.getCell(7);
                    Cell lineEffectiveFromCell = excelRateCardLineRow.getCell(8);
                    Cell lineEffectiveToCell = excelRateCardLineRow.getCell(9);
                    Cell commentsCell = excelRateCardLineRow.getCell(10);

                    String lineNumberData = RateCardBackingBean.getStringCellValue(lineNumberCell, workbook);
                    String roleType = RateCardBackingBean.getStringCellValue(roleTypeCell, workbook);
                    String role = RateCardBackingBean.getStringCellValue(roleCell, workbook);
                    String region = RateCardBackingBean.getStringCellValue(regionCell, workbook);
                    String workType = RateCardBackingBean.getStringCellValue(workTypeCell, workbook);
                    String rateType = RateCardBackingBean.getStringCellValue(rateTypeCell, workbook);
                    String rateValue = RateCardBackingBean.getStringCellValue(rateCell, workbook);
                    String uom = RateCardBackingBean.getStringCellValue(uomCell, workbook);
                    String lineEffectiveFromData = RateCardBackingBean.getDateCellValue(lineEffectiveFromCell);
                    String lineEffectiveToData = RateCardBackingBean.getDateCellValue(lineEffectiveToCell);
                    String comments = RateCardBackingBean.getStringCellValue(commentsCell, workbook);

                    oracle.jbo.domain.Number lineNumber = new oracle.jbo.domain.Number(lineNumberData);
                    oracle.jbo.domain.Number rate = new oracle.jbo.domain.Number(rateValue);

                    Date lineEffectiveFromDate = castToJBODate(lineEffectiveFromData);
                    Date lineEffectiveToDate = castToJBODate(lineEffectiveToData);

                    oracle.jbo.Row rateCardLineRow = rateCardLinesVO.createRow();

                    rateCardLineRow.setAttribute("RateCardLineNumber", lineNumber);
                    rateCardLineRow.setAttribute("RoleType", roleType);
                    rateCardLineRow.setAttribute("Role", role);
                    rateCardLineRow.setAttribute("Region", region);
                    rateCardLineRow.setAttribute("WorkType", workType);
                    rateCardLineRow.setAttribute("RateType", rateType);
                    rateCardLineRow.setAttribute("Rate", rate);
                    rateCardLineRow.setAttribute("Uom", uom);
                    rateCardLineRow.setAttribute("EffectiveDateFrom", lineEffectiveFromDate);
                    rateCardLineRow.setAttribute("EffectiveDateTo", lineEffectiveToDate);
                    rateCardLineRow.setAttribute("Comments", comments);

                    rateCardLinesVO.insertRow(rateCardLineRow);

                }

                ADFUtils.findOperation("Commit").execute();
                JSFUtils.addFacesInformationMessage("Rate card uploaded successfully");


            } catch (IOException e) {
                e.printStackTrace();
                JSFUtils.addFacesErrorMessage("Some error occured while reading the file. Please try again");

            } catch (SQLException e) {
                e.printStackTrace();
                JSFUtils.addFacesErrorMessage("Some error occured while creating the rate card. Please correct the data and try again");

            } catch (InvalidFormatException e) {
                e.printStackTrace();
                JSFUtils.addFacesErrorMessage("Some error occured while creating the rate card. Please correct the data and try again");
            }
        } else {
            JSFUtils.addFacesErrorMessage("Please Select a file to upload");
        }
    }


    public void setRateCardFile(UploadedFile rateCardFile) {
        this.rateCardFile = rateCardFile;
    }

    public UploadedFile getRateCardFile() {
        return rateCardFile;
    }

    public static String getStringCellValueDecimal(Cell cell, Workbook workbook) {
        String value = null;
        if (cell != null) {
            int cellType = cell.getCellType();
            switch (cellType) {
            case 0:
                { //CellType is Numeric
                    BigDecimal doubleValue = BigDecimal.valueOf(cell.getNumericCellValue());
                    if (doubleValue != null) {
                        value = String.valueOf(doubleValue);
                    }
                }
                break;
            case 1: //CellType is AlphaNumeric
                value = cell.getStringCellValue();
                break;
            case 2:
                { //CellType is Formula
                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                    BigDecimal doubleValue = BigDecimal.valueOf(evaluator.evaluateInCell(cell).getNumericCellValue());
                    if (doubleValue != null) {
                        value = String.valueOf(doubleValue);
                    }
                }
                break;
            default:
                value = cell.getStringCellValue();
                break;
            }
        }

        return value;
    }

    public static String getStringCellValue(Cell cell, Workbook workbook) {
        String value = null;
        if (cell != null) {
            int cellType = cell.getCellType();
            switch (cellType) {
            case 0:
                { //CellType is Numeric
                    Double doubleValue = cell.getNumericCellValue();
                    Long longValue = doubleValue.longValue();
                    value = longValue.toString();
                }
                break;
            case 1: //CellType is AlphaNumeric
                value = cell.getStringCellValue();
                break;
            case 2:
                { //CellType is Formula
                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                    Double doubleValue = evaluator.evaluateInCell(cell).getNumericCellValue();
                    Long longValue = doubleValue.longValue();
                    value = longValue.toString();
                }
                break;

            default:
                value = cell.getStringCellValue();
                break;
            }
        }

        return value;
    }

    public static String getDateCellValue(Cell cell) {
        String value = null;
        if (cell != null) {
            int cellType = cell.getCellType();
            switch (cellType) {
            case 0:
                { //Excel Default date format is Numeric
                    if (DateUtil.isCellDateFormatted(cell)) { //Checking if Cell is Excel date formatted
                        java.util.Date date = cell.getDateCellValue();
                        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                        value = df.format(date);
                    } else {
                        value = "INVALID_DATE";
                    }
                }
                break;
            case 1:
                {
                    try { //date entered as String
                        DateFormat dfSource = new SimpleDateFormat("dd-MMM-yyyy");
                        DateFormat dfDest = new SimpleDateFormat("yyyy-MM-dd");
                        String tempFormat = cell.getStringCellValue();
                        java.util.Date date = dfSource.parse(tempFormat);
                        value = dfDest.format(date);
                    } catch (ParseException pe) {
                        value = "INVALID_DATE";
                    }
                }
                break;
            default:
                value = null;
                break;
            }
        }

        return value;
    }

    public static oracle.jbo.domain.Date castToJBODate(String aDate) {
        DateFormat formatter;
        java.util.Date date;

        if (aDate != null) {

            try {

                formatter = new SimpleDateFormat("yyyy-MM-dd");
                date = formatter.parse(aDate);
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                oracle.jbo.domain.Date jboDate = new oracle.jbo.domain.Date(sqlDate);

                return jboDate;
            } catch (ParseException e) {

                e.printStackTrace();
            }

        }

        return null;
    }


    public void submitRateCard(ActionEvent actionEvent) {
        oracle.jbo.Row rateCardHeaderRow = ADFUtils.findIterator("RateCardHeaderIterator").getCurrentRow();
        String email = (String) rateCardHeaderRow.getAttribute("Email");
        rateCardHeaderRow.setAttribute("Status", "SUBMITTED");
        ADFUtils.findOperation("Commit").execute();
    }

    public void saveRateCard(ActionEvent actionEvent) {
        BindingContext ctx3 = BindingContext.getCurrent();
        DCBindingContainer bc3 = (DCBindingContainer) ctx3.getCurrentBindingsEntry();
        DCIteratorBinding iterator3 = bc3.findIteratorBinding("RateCardLineIterator");
        oracle.jbo.Row currRow = iterator3.getCurrentRow();
        try {
            lineNumber = currRow.getAttribute("RateCardLineNumber").toString();
        } catch (NullPointerException e) {
            JSFUtils.addFacesErrorMessage("Please Enter LineNumber");
        }
        try {
            rate = currRow.getAttribute("Rate").toString();
        } catch (NullPointerException e) {
            JSFUtils.addFacesErrorMessage("Please Enter Rate");
        }
        System.out.println("this.getLineNumber()..."+this.getLineNumber());
        System.out.println("this.getRate()..."+this.getRate());
        
        if (this.getLineNumber() != null && this.getRate() != null) {
            System.out.println("Submitting...");
        }
        
        oracle.jbo.Row rateCardHeaderRow = ADFUtils.findIterator("RateCardHeaderIterator").getCurrentRow();
        oracle.jbo.domain.Number approver = (oracle.jbo.domain.Number) rateCardHeaderRow.getAttribute("ApprovedBy");
        String status = (String) rateCardHeaderRow.getAttribute("Status");
        if (status.equalsIgnoreCase("ENTERED")) {
            if (approver == null) {
                oracle.jbo.domain.Number defaultBuyerId =
                    (oracle.jbo.domain.Number) rateCardHeaderRow.getAttribute("DefaultBuyerId");
                if (defaultBuyerId == null) {
                    JSFUtils.addFacesErrorMessage("Default buyer not defined for the supplier");
                    return;
                }
                rateCardHeaderRow.setAttribute("ApprovedBy", defaultBuyerId);
            }
        }

        oracle.jbo.domain.Number poHeaderId = (oracle.jbo.domain.Number) rateCardHeaderRow.getAttribute("PoHeaderId");
        if (poHeaderId != null) {
            oracle.jbo.Row[] rows =
                ADFUtils.findIterator("RateCardSearchIterator").getViewObject().getFilteredRows("PoHeaderId",
                                                                                                poHeaderId);
            if (rows != null && rows.length > 0) {
                for (oracle.jbo.Row row : rows) {
                    oracle.jbo.domain.Number rateCardNumber =
                        (oracle.jbo.domain.Number) ADFUtils.getBoundAttributeValue("RateCardNumber");
                    oracle.jbo.domain.Number curRateCardNumber =
                        (oracle.jbo.domain.Number) row.getAttribute("RateCardNumber");
                    if (rateCardNumber.compareTo(curRateCardNumber) != 0) {
                        Date fromDate = (Date) row.getAttribute("EffectiveDateFrom");
                        Date toDate = (Date) row.getAttribute("EffectiveDateTo");

                        Date curFromDate = (Date) ADFUtils.getBoundAttributeValue("EffectiveDateFrom");
                        Date curToDate = (Date) ADFUtils.getBoundAttributeValue("EffectiveDateTo");

                        if (fromDate.compareTo(curFromDate) < 0 && toDate != null &&
                            toDate.compareTo(curFromDate) < 0) {
                        } else if (fromDate.compareTo(curFromDate) > 0 && curToDate != null &&
                                   fromDate.compareTo(curToDate) > 0) {
                        } else {
                            JSFUtils.addFacesErrorMessage("Rate card already defined for the selected contract for the mentioned effective period");
                            return;
                        }
                    }
                }
            }
        } else {
            oracle.jbo.domain.Number supplierId =
                (oracle.jbo.domain.Number) rateCardHeaderRow.getAttribute("SupplierId");
            oracle.jbo.Row[] rows =
                ADFUtils.findIterator("RateCardSearchIterator").getViewObject().getFilteredRows("SupplierId",
                                                                                                supplierId);
            if (rows != null && rows.length > 0) {
                for (oracle.jbo.Row row : rows) {
                    oracle.jbo.domain.Number rateCardNumber =
                        (oracle.jbo.domain.Number) ADFUtils.getBoundAttributeValue("RateCardNumber");
                    oracle.jbo.domain.Number curRateCardNumber =
                        (oracle.jbo.domain.Number) row.getAttribute("RateCardNumber");
                    if (rateCardNumber.compareTo(curRateCardNumber) != 0) {
                        oracle.jbo.domain.Number oldPoHeaderId =
                            (oracle.jbo.domain.Number) row.getAttribute("PoHeaderId");
                        if (oldPoHeaderId == null) {
                            Date fromDate = (Date) row.getAttribute("EffectiveDateFrom");
                            Date toDate = (Date) row.getAttribute("EffectiveDateTo");

                            Date curFromDate = (Date) ADFUtils.getBoundAttributeValue("EffectiveDateFrom");
                            Date curToDate = (Date) ADFUtils.getBoundAttributeValue("EffectiveDateTo");

                            if (fromDate.compareTo(curFromDate) < 0 && toDate != null &&
                                toDate.compareTo(curFromDate) < 0) {
                            } else if (fromDate.compareTo(curFromDate) > 0 && curToDate != null &&
                                       fromDate.compareTo(curToDate) > 0) {
                            } else {
                                JSFUtils.addFacesErrorMessage("Rate card already defined for the selected supplier for the mentioned effective period");
                                return;
                            }
                        }
                    }
                }
            }
        }
        if (this.getLineNumber() != null && this.getRate() != null) {
            rateCardHeaderRow.setAttribute("Status", "DRAFT");
            ADFUtils.findOperation("Commit").execute();
            JSFUtils.addFacesInformationMessage("Changes Saved Successfully");
        }
    }

    public void approveRateCard(ActionEvent actionEvent) {
        oracle.jbo.Row rateCardHeaderRow = ADFUtils.findIterator("RateCardHeaderIterator").getCurrentRow();
        rateCardHeaderRow.setAttribute("Status", "APPROVED");
        java.util.Date today = new java.util.Date();
        //send mail to supplier

        try {
            rateCardHeaderRow.setAttribute("ApprovedDate", new Date(new java.sql.Date(today.getTime())));
            ADFUtils.findOperation("Commit").execute();
        } catch (Exception e) {
            JSFUtils.addFacesErrorMessage("Some Error occured while saving the changes. Try saving the changes again");
            e.printStackTrace();
            return;
        }
        JSFUtils.addFacesInformationMessage("Changes saved succesfully");
    }

    public void rejectRateCard(ActionEvent actionEvent) {
        oracle.jbo.Row rateCardHeaderRow = ADFUtils.findIterator("RateCardHeaderIterator").getCurrentRow();
        rateCardHeaderRow.setAttribute("Status", "REJECTED");
        //send mail to supplier
        try {
            ADFUtils.findOperation("Commit").execute();
        } catch (Exception e) {
            JSFUtils.addFacesErrorMessage("Some Error occured while saving the changes. Try saving the changes again");
            e.printStackTrace();
            return;
        }
        JSFUtils.addFacesInformationMessage("Changes saved succesfully");
    }

    public void poHeaderIdSearchChangeListener(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());

        OperationBinding executeSupplierSites = ADFUtils.findOperation("ExecuteSupplierSites");
        System.out.println("Value of supplier Id-" + ADFUtils.getBoundAttributeValue("SupplierId1"));
        executeSupplierSites.getParamsMap().put("bSupplierId", ADFUtils.getBoundAttributeValue("SupplierId1"));
        this.setSupplierSiteIdVal(ADFUtils.getBoundAttributeValue("SupplierId1").toString());
        executeSupplierSites.execute();
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndSupplierSiteId());
    }

    public void supplierIdSearchChangeListener(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        //        OperationBinding executeContractLOV =
        //            ADFUtils.findOperation("ExecuteContractLOV");
        //        executeContractLOV.getParamsMap().put("bSupplierId",
        //                                              ADFUtils.getBoundAttributeValue("SupplierId1"));
        //        executeContractLOV.execute();
        //
        //        ADFUtils.setBoundAttributeValue("PoHeaderId1", null);


        OperationBinding executeSupplierSites = ADFUtils.findOperation("ExecuteSupplierSites");
        System.out.println("Value of supplier Id-" + ADFUtils.getBoundAttributeValue("SupplierId1"));
        executeSupplierSites.getParamsMap().put("bSupplierId", ADFUtils.getBoundAttributeValue("SupplierId1"));
        this.setSupplierSiteIdVal(ADFUtils.getBoundAttributeValue("SupplierId1").toString());
        executeSupplierSites.execute();
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndSupplierSiteId());
    }

    public void supplierSiteIdSearchChangeListener(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        String lovValue = valueChangeEvent.getNewValue().toString();
        System.out.println("lovValue..." + lovValue);
        this.setSupplierSiteId(valueChangeEvent.getNewValue().toString());

    }

    public void searchRateCards(ActionEvent actionEvent) {
        String userRole = (String) JSFUtils.getFromSession("role");
        oracle.jbo.domain.Number partyId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("partyId");

        OperationBinding searchrateCards = ADFUtils.findOperation("SearchRateCards");
        Map paramMap = searchrateCards.getParamsMap();
        paramMap.put("bPoHeaderId", ADFUtils.getBoundAttributeValue("PoHeaderId1"));
        if (userRole.equalsIgnoreCase("SUPPLIER")) {
            paramMap.put("bSupplierId", partyId);
        } else {
            paramMap.put("bSupplierId", ADFUtils.getBoundAttributeValue("SupplierId1"));
        }
        paramMap.put("bRateCardNumber", ADFUtils.getBoundAttributeValue("RateCardNumber1"));
        paramMap.put("bSupplierSiteId", this.getSupplierSiteId());
        searchrateCards.execute();
    }

    public void applyUserRestrictions() {
        String userRole = (String) JSFUtils.getFromSession("role");
        //System.out.println("userRole..."+userRole);
       // oracle.jbo.domain.Number partyId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("partyId");
        //System.out.println("partyId..."+partyId);
        
        
        
               SecurityContext securityCtx = ADFContext.getCurrent(). getSecurityContext();
               String[] Roles = securityCtx.getUserRoles();
               
        String role=Roles[0];
        /*
               for(String role: Roles){
                   roles = roles + "\n" + role;
                   System.out.println("Check Role:"+roles+"\n");
               }
        */
        System.out.println("Check Role:"+role);
        JSFUtils.storeOnSession("role", role);
        userRole=role;
        System.out.println("userRole..."+userRole);
        
        oracle.jbo.domain.Number employeeId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("employeeId");

        if (userRole.equalsIgnoreCase("BUYER")) {
            OperationBinding executeContractLOV = ADFUtils.findOperation("ExecuteContractLOV");
            OperationBinding executeRateCardHeader = ADFUtils.findOperation("ExecuteRateCardHeader");
            //  executeContractLOV.getParamsMap().put("bSupplierId", employeeId);
            //  executeRateCardHeader.getParamsMap().put("bSupplierId", employeeId);

            executeContractLOV.getParamsMap().put("bBuyerId", employeeId);
            executeRateCardHeader.getParamsMap().put("bBuyerId", employeeId);
            executeContractLOV.execute();
            executeRateCardHeader.execute();
        }

        else {

            OperationBinding executeContractLOV = ADFUtils.findOperation("ExecuteContractLOV");
            OperationBinding executeRateCardHeader = ADFUtils.findOperation("ExecuteRateCardHeader");
            //  executeContractLOV.getParamsMap().put("bSupplierId", employeeId);
            //  executeRateCardHeader.getParamsMap().put("bSupplierId", employeeId);

            executeContractLOV.getParamsMap().put("bBuyerId", employeeId);
            executeRateCardHeader.getParamsMap().put("bBuyerId", employeeId);
            executeContractLOV.execute();
            executeRateCardHeader.execute();
        }
    }

    public void getLineNumberValue(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        //        try {
        //            setLineNumber(valueChangeEvent.getNewValue().toString());
        //        } catch (NullPointerException e) {
        //            JSFUtils.addFacesErrorMessage("Please Enter LineNumber");
        //            System.out.print("NullPointerException Caught");
        //        }
        //        System.out.println("getLineNumberValue.." + valueChangeEvent.getNewValue().toString());
    }

    public void getRateValue(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        //        try {
        //            setRate(valueChangeEvent.getNewValue().toString());
        //        } catch (NullPointerException e) {
        //           // JSFUtils.addFacesErrorMessage("Please Enter Rate");
        //            System.out.print("NullPointerException Caught");
        //        }
        //        System.out.println("getRateValue.." + valueChangeEvent.getNewValue().toString());
    }

    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    public String getLineNumber() {
        return lineNumber;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getRate() {
        return rate;
    }

    public void getPoId(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        setPoIdValue(valueChangeEvent.getNewValue().toString());
        System.out.println("poIdValue..." + poIdValue);
        BindingContext ctx1 = BindingContext.getCurrent();
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("ProcurementView1Iterator");
        ViewObjectImpl vo = (ViewObjectImpl) iterator.getViewObject();
        ViewCriteria vc = vo.getViewCriteria("ProcurementViewCriteria");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bPOId", poIdValue);
        vo.executeQuery();
        oracle.jbo.Row poHeaderRow = iterator.getCurrentRow();
        String BuName = (String) poHeaderRow.getAttribute("BuName");
        System.out.println("BuName..." + BuName);

        getBndBUName().setValue(BuName);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndBUName());

    }

    public void setPoIdValue(String poIdValue) {
        this.poIdValue = poIdValue;
    }

    public String getPoIdValue() {
        return poIdValue;
    }


    public void setBndBUName(RichOutputText bndBUName) {
        this.bndBUName = bndBUName;
    }

    public RichOutputText getBndBUName() {
        return bndBUName;
    }

    public void setSupplierSiteIdVal(String supplierSiteIdVal) {
        this.supplierSiteIdVal = supplierSiteIdVal;
    }

    public String getSupplierSiteIdVal() {
        return supplierSiteIdVal;
    }

    public void setBndSupplierSiteId(RichSelectOneChoice bndSupplierSiteId) {
        this.bndSupplierSiteId = bndSupplierSiteId;
    }

    public RichSelectOneChoice getBndSupplierSiteId() {
        return bndSupplierSiteId;
    }

    public void setSupplierSiteId(String supplierSiteId) {
        this.supplierSiteId = supplierSiteId;
    }

    public String getSupplierSiteId() {
        return supplierSiteId;
    }

    public void setBndBuName1(RichPanelFormLayout bndBuName1) {
        this.bndBuName1 = bndBuName1;
    }

    public RichPanelFormLayout getBndBuName1() {
        return bndBuName1;
    }


    public void createLineNumber(ActionEvent actionEvent) {
        // Add event code here...
        //        DCBindingContainer bindings = (DCBindingContainer) BindingContext.getCurrent().getCurrentBindingsEntry();
        //        OperationBinding operationBinding = bindings.getOperationBinding("CreateInsert");
        //        System.out.println("executed...");
        //        operationBinding.execute();

        DCBindingContainer bc = (DCBindingContainer) BindingUtils.getBindingContext().getCurrentBindingsEntry();

        DCIteratorBinding iterator = bc.findIteratorBinding("RateCardLineIterator");
        ViewObjectImpl lineVo = (ViewObjectImpl) iterator.getViewObject();
        oracle.jbo.Row lineRow = (oracle.jbo.Row) lineVo.createRow();

        lineRow.setNewRowState(oracle.jbo.Row.STATUS_INITIALIZED);
        lineNumCounter = (int) iterator.getEstimatedRowCount();
        lineNumCounter = lineNumCounter + 1;
        oracle.jbo.domain.Number lineNum = new oracle.jbo.domain.Number(lineNumCounter);
        System.out.println("lineNum..." + lineNum);
        lineRow.setAttribute("RateCardLineNumber", lineNum);
        lineVo.last();
        lineVo.next();
        lineVo.insertRow(lineRow);

        getBndLineNumber().setValue(lineNum);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndLineNumber());
        AdfFacesContext.getCurrentInstance().addPartialTarget(bndTable);

    }

    public void setBndLineNumber(RichInputText bndLineNumber) {
        this.bndLineNumber = bndLineNumber;
    }

    public RichInputText getBndLineNumber() {
        return bndLineNumber;
    }

    public void setBndTable(RichTable bndTable) {
        this.bndTable = bndTable;
    }

    public RichTable getBndTable() {
        return bndTable;
    }
}
