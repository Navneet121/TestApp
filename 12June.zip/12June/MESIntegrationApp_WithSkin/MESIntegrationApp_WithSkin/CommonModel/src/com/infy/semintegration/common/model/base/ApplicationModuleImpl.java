package com.infy.semintegration.common.model.base;


public class ApplicationModuleImpl extends oracle.jbo.server.ApplicationModuleImpl {
//    private static CustomADFLogger LOGGER = CustomADFLogger.createADFLogger(ApplicationModuleImpl.class);

    public ApplicationModuleImpl() {
        super();
    }

}
